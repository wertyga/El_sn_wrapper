module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("electron");

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.loginScreen = exports.menuTemplate = exports.mainWindow = undefined;

var _path = __webpack_require__(2);

var _path2 = _interopRequireDefault(_path);

var _url = __webpack_require__(3);

var _axios = __webpack_require__(4);

var _axios2 = _interopRequireDefault(_axios);

__webpack_require__(5);

var _electron = __webpack_require__(0);

var _electronDevtoolsInstaller = __webpack_require__(19);

var _electronDevtoolsInstaller2 = _interopRequireDefault(_electronDevtoolsInstaller);

var _globals = __webpack_require__(20);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var mainWindow = exports.mainWindow = void 0;

var userID = void 0; // userID that login in app;

var NODE_ENV = process.env.NODE_ENV || 'development';
var isDevMode = NODE_ENV === 'development';
var isProd = NODE_ENV === 'production';

var menuTemplate = exports.menuTemplate = [{
    label: 'Reload',
    role: 'reload',
    accelerator: 'CommandOrControl+R'
}, {
    label: 'Quit',
    role: 'quit',
    accelerator: 'CommandOrControl+Q'
}, {
    label: 'Shortcuts',
    submenu: [{
        label: 'Reload - CTRL(CMD) + R'
    }, { type: 'separator' }, {
        label: 'Quit - CTRL(CMD) + Q'
    }]
}];
if (false) {
    menuTemplate.push({
        label: 'DevTools',
        role: 'toggleDevTools',
        accelerator: 'CommandOrControl+Shift+I'
    });
};

var loginScreen = exports.loginScreen = {
    width: 330,
    height: 600,
    resizable: false,
    frame: true,
    title: 'Crypto Signer',
    icon: _electron.nativeImage.createFromPath(__dirname + '/../icons/crypto_signer_app.png')
};

var createWindow = function createWindow() {
    // Create the browser window.
    var mainMenu = _electron.Menu.buildFromTemplate(menuTemplate);
    _electron.Menu.setApplicationMenu(mainMenu);
    exports.mainWindow = mainWindow = new _electron.BrowserWindow(loginScreen);

    // and load the index.html of the app.
    mainWindow.loadURL((0, _url.format)({
        pathname: _path2.default.join(__dirname, '..', 'static', 'index.html'),
        protocol: 'file',
        slashes: true
    }));
    // Open the DevTools.
    if (false) {
        (0, _electronDevtoolsInstaller2.default)(_electronDevtoolsInstaller.REACT_DEVELOPER_TOOLS);
        (0, _electronDevtoolsInstaller2.default)(_electronDevtoolsInstaller.REDUX_DEVTOOLS);
        // mainWindow.webContents.openDevTools();
    };

    // Emitted when the window is closed.
    mainWindow.on('closed', function () {
        // Dereference the window object, usually you would store windows
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        exports.mainWindow = mainWindow = null;
    });
};

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
_electron.app.on('ready', createWindow);

// Quit when all windows are closed.
_electron.app.on('window-all-closed', function () {
    // On OS X it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
        _electron.app.quit();
    }
});

_electron.app.on('activate', function () {
    // On OS X it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (mainWindow === null) {
        createWindow();
    }
});

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and import them here.

_electron.app.on('quit', function () {
    if (userID) _axios2.default.get((0, _globals.host)('/auth/quit-app/' + userID));
});

// Take user id
_electron.ipcMain.on('login_user_id', function (e, user_id) {
    userID = user_id;
});

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("axios");

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _electron = __webpack_require__(0);

var _electron2 = __webpack_require__(1);

var _compileSymbols = __webpack_require__(6);

var _compileSymbols2 = _interopRequireDefault(_compileSymbols);

var _index = __webpack_require__(7);

var _index2 = _interopRequireDefault(_index);

var _crypto_signer_app = __webpack_require__(18);

var _crypto_signer_app2 = _interopRequireDefault(_crypto_signer_app);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Functions
var resizeMainScreen = function resizeMainScreen(win) {
    win.maximize();
    win.setResizable(true);
    win.setMaximizable(true);
    win.center();
};
var resizeToLoginScreen = function resizeToLoginScreen(win) {
    win.setSize(_electron2.loginScreen.width, _electron2.loginScreen.height);
    win.setResizable(_electron2.loginScreen.resizable);
    win.center();
};

// Socket data
_electron.ipcMain.on('login_user', function (e, msg) {
    // Resize main window
    resizeMainScreen(_electron2.mainWindow);
});
_electron.ipcMain.on('logout_user', function (e, msg) {
    // Resize main window
    resizeToLoginScreen(_electron2.mainWindow);
});
_electron.ipcMain.on('reached_sign_price', function (e, msg) {
    var notification = new _index2.default({
        icon: {
            image: _crypto_signer_app2.default,
            title: _electron.nativeImage.createFromPath(__dirname + '/../icons/crypto_signer_app.png'),
            width: '10%'
        },
        title: {
            text: (0, _compileSymbols2.default)(msg.symbol)
        },
        text: {
            text: '<div>Has been reached sign price - ' + msg.signPrice.toFixed(8) + '</div> <div>Time: ' + msg.time.split('.')[0] + '</div>',
            'margin-left': 10,
            'margin-top': 5
        },
        width: 400,
        height: 100,
        closeTimeout: 1000 * 60 * 60
    });
    notification.show();
    notification.on('click', function () {
        return notification.close();
    });
});

var symbols = []; // Symbols that are already have been shown
_electron.ipcMain.on('get_new_powers', function (e, data) {
    // Emit if get a percent high Or low
    var title = 'Bounce price';
    var text = data.map(function (item) {
        if (symbols.indexOf(item.symbol) !== -1) return '';

        symbols.push(item.symbol);
        var text = void 0;
        if (item.percent > 0) {
            text = 'Just jump up for +' + item.percent + '%';
        } else {
            text = 'Crush down for ' + item.percent + '% \n From: ' + item.high.toFixed(8) + ' To: ' + item.close.toFixed(8);
        };
        return '<div><strong>' + (0, _compileSymbols2.default)(item.symbol) + '</strong></div>' + ('<div>' + text + '</div>');
    }).filter(function (item) {
        return !!item;
    });

    text = text.length > 3 ? text.splice(0, 3).join('\n') + 'more...' : text.join('\n');
    var notifyHeight = data.length > 3 ? 50 * 3 + 10 + 20 : 50 * data.length + 20 + 20;

    if (text.length < 1) return;

    var notify = new _index2.default({
        title: {
            text: title
        },
        text: {
            text: text,
            'margin-left': 10
        },
        width: 400,
        height: notifyHeight,
        icon: {
            image: _crypto_signer_app2.default,
            title: _electron.nativeImage.createFromPath(__dirname + '/../icons/crypto_signer_app.png'),
            width: '10%'
        },
        closeTimeout: 1000 * 60 * 60
    });
    notify.show();

    notify.on('close', function () {
        data.forEach(function (item) {
            setSeenWithCloseNotification(e, item);
            symbols.splice(symbols.indexOf(item.symbol), 1);
        });
        // notification.close();
    });
    notify.on('click', function () {
        _electron2.mainWindow.focus();
        _electron2.mainWindow.maximize();
        e.sender.send('go_to_power_page');
        notify.close();
    });
});

_electron.ipcMain.on('Error_in_set_seen_power', function (e, msg) {
    var errorNotification = new _electron.Notification({
        title: 'Error in power symbol'.toUpperCase(),
        body: msg
    });

    errorNotification.show();
});

_electron.app.on('ready', function () {});

// ipcMain.on('notify', () => {
//     const notify = new WeNotify({
//         title: {
//             text: 'TITLE'
//         },
//         text: {
//             text: 'asjkhdjash jkdhasjk hdnsah dhsajk hdkjsagh dhasjk hdjsah djhasjk hdsah dhaksj dhsa jkhdhsa djhaskj hdksah kdajsh dk' +
//             'agsd jhajks hdjhsak jhdjsa hjkdhkajsh kdhasjk hdksah kjdhkajsh dkhsakhd kajshd haksjhd kjahskdhaksjhd kjahsjkd hkajshd khasjkd h' +
//             'lajskdjsakj dljas ljdjsa djsa jdjsaj dljasl dlsajl djjsaljd lkajsld lsa d',
//             'margin-left': 10
//         },
//         width: 400,
//         height: 200,
//         icon: {
//             image: icon,
//             title: nativeImage.createFromPath(__dirname + '/../icons/crypto_signer_app.png'),
//             width: '10%',
//
//         },
//         maxWindows: 3,
//     });
//
//     notify.on('close', () => {
//         console.log('close')
//     })
//     notify.on('show', () => {
//         console.log('show')
//     })
//     notify.on('click', () => {
//         console.log('click')
//     })
//
//     notify.show()
// });

function setSeenWithCloseNotification(e, item) {
    e.sender.send('set_seen_power', item._id);
};

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

// Compile symbol name
exports.default = function (symbol) {
    return symbol === 'BTCUSDT' ? 'BTC / USDT' : symbol.split('BTC').join(' / BTC');
};

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _keys = __webpack_require__(8);

var _keys2 = _interopRequireDefault(_keys);

var _extends2 = __webpack_require__(9);

var _extends3 = _interopRequireDefault(_extends2);

var _promise = __webpack_require__(10);

var _promise2 = _interopRequireDefault(_promise);

var _slicedToArray2 = __webpack_require__(11);

var _slicedToArray3 = _interopRequireDefault(_slicedToArray2);

var _getPrototypeOf = __webpack_require__(12);

var _getPrototypeOf2 = _interopRequireDefault(_getPrototypeOf);

var _classCallCheck2 = __webpack_require__(13);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(14);

var _createClass3 = _interopRequireDefault(_createClass2);

var _possibleConstructorReturn2 = __webpack_require__(15);

var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);

var _inherits2 = __webpack_require__(16);

var _inherits3 = _interopRequireDefault(_inherits2);

var _events = __webpack_require__(17);

var _events2 = _interopRequireDefault(_events);

var _electron = __webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// Properties
//     title: {
//         text: 'Tile text' // <strong>Some markup</strong> - available
//             // styles of title
//     },
//     text: {
//         text: 'Tile text'
//         // styles of text
//     },
//     width: width || 400,
//     height: height || 200,
//     icon: {
//         image: icon image,
//         title: image of window title
//          // Styles of image wrapper
//     },
//     rootStyles: {
//       // Root styles
//      },
//     closeTimeout: Close time || 6000,
//     maxWindows: // Windows count
//     mainContent: // mainContent styles,
//     horizPos: // Horizontal position
//     vertPos: // Vertical position,
//     useContentSize: // ContentSize of BrowserWindow
//     appearTransitionSpeed: // Speed of window moving(default: 8ms)
//     leaveTransitionSpeed: // Speed of window moving(default: 6ms)
//     useContentSize: // Is use content size

var _winIDs = [];
var _queue = [];
var _max = 3;
var isMaxHeight = 0;

var looseBetweenNotifications = 5;

var WeNotify = function (_EventEmitter) {
    (0, _inherits3.default)(WeNotify, _EventEmitter);

    function WeNotify(opt) {
        (0, _classCallCheck3.default)(this, WeNotify);

        var _this = (0, _possibleConstructorReturn3.default)(this, (WeNotify.__proto__ || (0, _getPrototypeOf2.default)(WeNotify)).call(this));

        _this.close = function () {
            if (_this._notifyWindow && process.platform !== 'linux') {
                _this._animateCloseToRightFromRightBottom().then(function () {
                    _winIDs.splice(_winIDs.indexOf(_this._notifyWindow.id), 1);
                    isMaxHeight -= _this._notifyWindow.getSize()[1];
                    _this._notifyWindow.close();
                }).catch(function (err) {
                    return console.error(err);
                });
            } else if (_this._notifyWindow) {
                _winIDs.splice(_winIDs.indexOf(_this._notifyWindow.id), 1);
                isMaxHeight -= _this._notifyWindow.getSize()[1];
                _this._notifyWindow.close();
            }
        };

        _this.bodyClick = function () {
            _this.emit('click');
        };

        _this._setEventHandleres = function (win) {
            win.on('show', function () {
                _this.emit('show');
                _winIDs.push(win.id);
                if (process.platform !== 'linux') {
                    _this._initialPositionRightBottom();
                    _this._appearFromRightToLeft();
                } else {
                    var _this$_getWindowPosit = _this._getWindowPositionRight(win),
                        horizPos = _this$_getWindowPosit.horizPos,
                        vertPos = _this$_getWindowPosit.vertPos;

                    win.setPosition(horizPos, vertPos);
                };

                setTimeout(function () {
                    if (win || !win.isDestroyed()) {
                        _this.close();
                    } else {
                        win = null;
                        return;
                    };
                }, _this.closeTimeout);

                // win.webContents.openDevTools();

                _electron.ipcMain.on('windowID-' + win.id, _this.close);
                _electron.ipcMain.on('body_click-' + win.id, _this.bodyClick);
            });

            win.on('close', function () {
                _this.emit('close');

                _this._notifyWindow = null;
                _electron.ipcMain.removeListener('windowID-' + win.id, _this.close);
                _electron.ipcMain.removeListener('body_click-' + win.id, _this.bodyClick);
            });
            win.on('closed', function () {
                if (_winIDs.length > 0) {
                    _this._launchMoveDownInRightBottom();
                };
                if (_queue.length > 0) {
                    _queue[0].show();
                    _queue.shift();
                };
            });
        };

        if (opt.maxWindows) _max = opt.maxWindows;
        _this.opt = opt;
        _this.notifyWidth = opt.width || 400;
        _this.notifyHeight = opt.height || 200;
        _this.horizPos = opt.horizPos || 20;
        _this.vertPos = opt.vertPos || 20;
        _this.appearTransitionSpeed = opt.appearTransitionSpeed || 8;
        _this.leaveTransitionSpeed = opt.leaveTransitionSpeed || 6;
        _this.closeTimeout = opt.closeTimeout || 6000;
        return _this;
    }

    (0, _createClass3.default)(WeNotify, [{
        key: 'show',
        value: function show() {
            var _screen$getPrimaryDis = _electron.screen.getPrimaryDisplay().workAreaSize,
                width = _screen$getPrimaryDis.width,
                height = _screen$getPrimaryDis.height;
            // Make window


            var _notifyWindow = new _electron.BrowserWindow({
                icon: this.opt.icon.title || false,
                maxWidth: width,
                maxHeight: height,
                parent: 'top',
                modal: true,
                frame: false,
                useContentSize: true,
                width: this.notifyWidth,
                height: this.notifyHeight,
                hasShadow: false,
                resizable: false,
                alwaysOnTop: true,
                show: false
            });

            // Load content
            var file = 'data:text/html;charset=UTF-8,' + encodeURIComponent(loadView(this.opt));
            _notifyWindow.loadURL(file);
            this._notifyWindow = _notifyWindow;

            this._setEventHandleres(_notifyWindow);

            //Check count of windows
            var checkHeights = isMaxHeight + _notifyWindow.getSize()[1] + looseBetweenNotifications * 2 >= _electron.screen.getPrimaryDisplay().workAreaSize.height;

            if (_winIDs.length < _max && !checkHeights) {
                _notifyWindow.show();
                _notifyWindow.focus();
                isMaxHeight += _notifyWindow.getSize()[1];
            } else {
                _queue.push(_notifyWindow);
            };
        }
    }, {
        key: '_initialPositionRightBottom',
        value: function _initialPositionRightBottom() {
            var _screen$getPrimaryDis2 = _electron.screen.getPrimaryDisplay().workAreaSize,
                width = _screen$getPrimaryDis2.width,
                height = _screen$getPrimaryDis2.height;

            var _getWindowPositionRig = this._getWindowPositionRight(this._notifyWindow),
                horizPos = _getWindowPositionRig.horizPos,
                vertPos = _getWindowPositionRig.vertPos;

            this._notifyWindow.setPosition(width, vertPos);
        }
    }, {
        key: '_appearFromRightToLeft',
        value: function _appearFromRightToLeft() {
            var _this2 = this;

            var timer = setInterval(function () {
                var _getWindowPositionRig2 = _this2._getWindowPositionRight(_this2._notifyWindow),
                    horizPos = _getWindowPositionRig2.horizPos,
                    vertPos = _getWindowPositionRig2.vertPos;

                var _notifyWindow$getPosi = _this2._notifyWindow.getPosition(),
                    _notifyWindow$getPosi2 = (0, _slicedToArray3.default)(_notifyWindow$getPosi, 2),
                    winX = _notifyWindow$getPosi2[0],
                    winY = _notifyWindow$getPosi2[1];

                if (winX <= horizPos) {
                    clearInterval(timer);
                    timer = null;
                } else {
                    _this2._notifyWindow.setPosition(Math.max(winX - 30, horizPos), vertPos);
                };
            }, this.appearTransitionSpeed);
        }
    }, {
        key: '_animateCloseToRightFromRightBottom',
        value: function _animateCloseToRightFromRightBottom() {
            var _this3 = this;

            return new _promise2.default(function (resolve, reject) {
                var timer = setInterval(function () {
                    var _getWindowPositionRig3 = _this3._getWindowPositionRight(_this3._notifyWindow),
                        horizPos = _getWindowPositionRig3.horizPos,
                        vertPos = _getWindowPositionRig3.vertPos;

                    var _screen$getPrimaryDis3 = _electron.screen.getPrimaryDisplay().workAreaSize,
                        width = _screen$getPrimaryDis3.width,
                        height = _screen$getPrimaryDis3.height;

                    var winX = _this3._notifyWindow.getPosition()[0];

                    if (winX >= width) {
                        clearInterval(timer);
                        timer = null;
                        resolve('Done!');
                    } else {
                        _this3._notifyWindow.setPosition(Math.min(winX + 30, width), vertPos);
                    };
                }, _this3.leaveTransitionSpeed);
            });
        }
    }, {
        key: '_getWindowPositionRight',
        value: function _getWindowPositionRight(win) {
            // Get screen sizes
            var _screen$getPrimaryDis4 = _electron.screen.getPrimaryDisplay().workAreaSize,
                width = _screen$getPrimaryDis4.width,
                height = _screen$getPrimaryDis4.height;

            var _win$getSize = win.getSize(),
                _win$getSize2 = (0, _slicedToArray3.default)(_win$getSize, 2),
                winWidth = _win$getSize2[0],
                winHeight = _win$getSize2[1];

            // Set position


            var horizPos = width - winWidth - this.horizPos;
            var vertPos = height - winHeight - this.vertPos - (winHeight + looseBetweenNotifications) * _winIDs.indexOf(win.id);
            return {
                horizPos: horizPos,
                vertPos: vertPos
            };
        }
    }, {
        key: '_getWindowPositionTop',
        value: function _getWindowPositionTop(win) {
            // Get sizes
            var _screen$getPrimaryDis5 = _electron.screen.getPrimaryDisplay().workAreaSize,
                width = _screen$getPrimaryDis5.width,
                height = _screen$getPrimaryDis5.height;

            var _win$getSize3 = win.getSize(),
                _win$getSize4 = (0, _slicedToArray3.default)(_win$getSize3, 2),
                winWidth = _win$getSize4[0],
                winHeight = _win$getSize4[1];

            // Set position


            var horizPos = width - winWidth - this.horizPos;
            var vertPos = this.vertPos + (winHeight + looseBetweenNotifications) * _winIDs.indexOf(win.id);
            return {
                horizPos: horizPos,
                vertPos: vertPos
            };
        }
    }, {
        key: '_moveWindowFromRight',
        value: function _moveWindowFromRight(windowID) {
            var window = _electron.BrowserWindow.fromId(windowID);
            if (!window) return;

            var _getWindowPositionRig4 = this._getWindowPositionRight(window),
                horizPos = _getWindowPositionRig4.horizPos,
                vertPos = _getWindowPositionRig4.vertPos;

            var timer = setInterval(function () {
                if (!window || window.isDestroyed()) {
                    window = null;
                    return;
                } else {
                    var _window$getPosition = window.getPosition(),
                        _window$getPosition2 = (0, _slicedToArray3.default)(_window$getPosition, 2),
                        winX = _window$getPosition2[0],
                        winY = _window$getPosition2[1];

                    if (winY >= vertPos) {
                        clearInterval(timer);
                        timer = null;
                    } else {
                        window.setPosition(winX, Math.min(winY + 30, vertPos));
                    }
                };
            }, 2);
        }
    }, {
        key: '_launchMoveDownInRightBottom',


        // _moveWindowFromTop(windowID) {
        //     const window = BrowserWindow.fromId(windowID);
        //     if(!window) return;
        //     const { horizPos, vertPos } = this._getWindowPositionTop(window);
        //     let timer = setInterval(() => {
        //         const [winX, winY] = window.getPosition();
        //         if(winY <= vertPos) {
        //             clearInterval(timer);
        //             timer = null;
        //         } else {
        //             window.setPosition(winX, Math.max(winY - 30, vertPos));
        //         }
        //     }, 2);
        // };

        value: function _launchMoveDownInRightBottom() {
            // Slide down upper notification when downer is closed
            for (var i = 0; i < _winIDs.length; i++) {
                this._moveWindowFromRight(_winIDs[i]);
            };
        }
    }]);
    return WeNotify;
}(_events2.default);

;

var loadView = function loadView(opt) {
    // Styles
    var iconStyles = (0, _extends3.default)({
        'margin-right': 10,
        width: '20%'
    }, filterObject(opt.icon, 'image'));
    var titleStyles = (0, _extends3.default)({
        'margin-bottom': 3,
        'font-weight': 'bold'
    }, filterObject(opt.title, 'text'));
    var textStyles = (0, _extends3.default)({
        'font-size': 13
    }, filterObject(opt.text, 'text'));
    var rootStyles = (0, _extends3.default)({
        'user-select': 'none',
        width: '100vw',
        height: '100vh',
        cursor: 'pointer',
        'padding-top': 20
    }, opt.rootStyles);
    var mainContent = (0, _extends3.default)({
        display: 'inline-flex',
        'padding-left': 10,
        'padding-right': 35,
        'padding-bottom': 10
    }, opt.mainContent);
    var closeStyle = {
        'text-align': 'right',
        'padding-top': '10px',
        'padding-right': '13px',
        position: 'absolute',
        right: 0,
        top: 0
    };
    var mainContentStylesString = (0, _keys2.default)(mainContent).map(function (item) {
        return item + ': ' + (typeof mainContent[item] === 'number' ? mainContent[item] + 'px' : mainContent[item]);
    }).join('; ');
    var iconStyleString = (0, _keys2.default)(iconStyles).map(function (item) {
        return item + ': ' + (typeof iconStyles[item] === 'number' ? iconStyles[item] + 'px' : iconStyles[item]);
    }).join('; ');
    var titleStyleString = (0, _keys2.default)(titleStyles).map(function (item) {
        return item + ': ' + (typeof titleStyles[item] === 'number' ? titleStyles[item] + 'px' : titleStyles[item]);
    }).join('; ');
    var textStyleString = (0, _keys2.default)(textStyles).map(function (item) {
        return item + ': ' + (typeof textStyles[item] === 'number' ? textStyles[item] + 'px' : textStyles[item]);
    }).join('; ');
    var rootStyleString = (0, _keys2.default)(rootStyles).map(function (item) {
        return item + ': ' + (typeof rootStyles[item] === 'number' ? rootStyles[item] + 'px' : rootStyles[item]);
    }).join('; ');
    var closeStyleString = (0, _keys2.default)(closeStyle).map(function (item) {
        return item + ': ' + (typeof closeStyle[item] === 'number' ? closeStyle[item] + 'px' : closeStyle[item]);
    }).join('; ');

    return '\n    <!DOCTYPE html>\n    <html lang="en">\n    <head>\n        <meta charset="UTF-8">\n        <title>' + opt.title.text + '</title>\n     \n    </head>\n    <body style="margin: 0; overflow: hidden;">\n    \n    <div class="close" style="' + closeStyleString + '"><span style="padding: 10px; cursor: pointer;">&times</span></div>\n        <div id="root" style="' + rootStyleString + '">\n            <div class="up"></div>\n            <div class="main" style="' + mainContentStylesString + '">\n                <div class="image" style="' + iconStyleString + '">\n                    <img style="width: 100%;" src=' + (opt.icon && opt.icon.image ? opt.icon.image : '') + ' alt="">\n                </div>\n                <div class="description" style="display: flex; flex-direction: column; flex: 1;">\n                    <div class="title" style="' + titleStyleString + '">' + opt.title.text + '</div>\n                    <div class="text" style="' + textStyleString + '">' + opt.text.text + '</div>\n                </div>\n            </div>\n            <div class="footer"></div>\n        </div>\n    \n        <script>        \n            let windowID = require(\'electron\').remote.getCurrentWindow().id;\n            var ipc = require(\'electron\').ipcRenderer;\n            function closeWindow() {\n                ipc.send(\'windowID-\' + windowID, windowID);\n            };\n            \n            window.onload = function() {\n                document.getElementById(\'root\').onclick = function(e) {\n                    ipc.send(\'body_click-\' + windowID, windowID);\n                };\n\n                // setTimeout(close, ' + (opt.closeTimeout || 6000) + ');\n                \n                const closeButton = document.querySelector(\'.close span\');\n                closeButton.onclick = closeWindow;\n            };\n                  \n           \n       \n        </script>\n    </body>\n    </html>\n  ';
};

function filterObject() {
    var obj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var fields = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

    if (!(fields instanceof Array)) fields = [fields];

    return (0, _keys2.default)(obj).filter(function (item) {
        if (fields.indexOf(item) !== -1) {
            return false;
        } else {
            return true;
        }
    }).reduce(function (init, item) {
        init[item] = obj[item];
        return init;
    }, {});
};

module.exports = WeNotify;

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/object/keys");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/extends");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/slicedToArray");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/object/get-prototype-of");

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/classCallCheck");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/createClass");

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/possibleConstructorReturn");

/***/ }),
/* 16 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/inherits");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAURJJREFUeNrsXXdUU80SnwRClyoYUUSwd8TesCBiV8SCxorYe++iop+9995uFEXsBSxIEAsoAqKgiAIGuLk3KNJ79v2RYHsqQdII+ztnz3mfL9y7d3fmtzOzuzMMhBBgYGBUTjDxEGBgYALAwMDABICBgYEJAAMDAxMABgYGJgAMDAxMABgYGJgAMDAwMAFgYGBgAsDAwMAEgIGBgQkAAwMDEwAGBgYmAAwMDEwAGBgYmAAwMDAwAWBgYGACwMDAwASAgYGBCQADAwMTAAYGBiYADAwMTAAYGBjyhiYegsoBR481LJaWjq4mS0tbQ0OTxWRqsABEIpEIFYtExaLi4uLCwvzc3HtHVuXg0ao8YODCIOqBQfP3WNaxrVW3WcMaNp0a1WhnyGIZAgCwLcytfviZQymPCSr5HwJayAcAKEKo6NG75ODQyMTYhER+/JVts/gVeZwGz99rtXfJCC8Wg/HXxW/1sQe7jix3e4EJAEPl4Lr4gHW3Ti06DG5frzeLwdD8puQ5fIeEeD4k8pMgKYWCpGQBpAiEIKBT4Wt6BnxNz4TsnFzIzy+A4qIiAAYAk6kBWixN0NbWBmMjQ6hqagwmJoZgWb0a1KldE9gWVaG2tRXUq28LoFszqIQYcoqKsy8FvfULDokMub5zTkpFGTsBLSQ+xYRwSJICYDD+/wcIgYGBHrTo2OPi1M2Xl17aPC0eEwCGUjFg7k72iIFd+/ZsatVDvKpXtRImhDtERr2DF+FR8CQ0AmJiPwIlICEzM0MufahiaAQWFhbQqH4d6Na5Ddi3aAKt7JqAoWXTIAEt5CMA4D6MvnI3INj/7uEVWao4joGR75fYVYN2JtXru5T2W5SXDCvORvbe4NHHX62FCyGEmwq2sWtONYtISNxCUjSBEOIlxYYgn7MH0Si3oahO3XoIAP7eGBqyacD44zuYGpqoQcPGaPqUCei27ymUI3yHSIomSIomfIIiJ/eZsdVMlcaUpGjCfcI4Sf+Zf/heQFraOghlJqLlx247q7ucYWVToTZ86eG6YfEJm8RKn8uLeHwHLZ4/CzVp2uwPSsiUnaKXmRiY/9cfbR1d1LlzZ3Ro9yaU/P75NzLYcznYrfuElUxlju3tkOjZGcLEGyVK/ufvAgTAQIVf3qPN3g9dMAHgJtfWw301a9/Vx24lK310WACaNX0KqlOnnvxWdbmRws/9bd+hIzp2YDvKFsYikqKJ2KTkA6NWHG+krNV/zqwZpROnpO+ZKVFo/43HbpgAcJNLG7Jgv3UMP2kfSdFEjjAWbdu8HjVv3qLiKb0UZKCrp4/c3NxQCO8WQgjxSIomFu+/4aiosfYJipycnyG4y9LSKX1MJX1OfvcMnbr/wh0TAG6y9e1Xn2pWYhpHhjxAozijka6uvnoovRRkYGdnh04fP4gQyuCRFE2sPu7XVxGr/4plS6RzmyT9fPcyAPk8jpyMCQA32Si+53fFv32Fi7p0cfhltddQP8X/CxHY2Niinds2IoTSeCRFE55yIoLTd1+4o4IvPP0qRtKRq6R/L3g3kF9EzFxMALiV29QvUfzrvgRq1aqVeq/2ZQwgWlnVQju3bfpmEczfe62brFf/zf+tkz5oKulXwO0LKPhd3EpMALj9U+s9bbNJND9pN0nRxIM7vqhNmzY/KD5D6QE66RpDYURgbW2Njh/e/23nwGX+PuvyzsHWC4GuCGXxjE2qSk+2kv5cu3gSRSXyd2ICwK3M7fD1Z2NIiibevw5BTk5Oil3x/7JvDwBIW1cPmZuzUY2atZB1bVtkW6cesrGti2pZ26DqljWRkbEpYmqwFHPG4Dd9bmlnh/xv+CCSoomn7z6u7enhpVee1f/Anm1lIzNJP4jj+9AnAXVK3WUVnwSUIcZ4nmqydUa/ZWwLbat5c1c77Nq9+4czlxpyPM1V/NN/amiwwLp2bWjZrCHYNWsEDerZgm3tmlCdbQFVzUxAy9QMAHQAgAXf74MVAkA+QH4GpKemgfDzZ4hP4EP8p2SIehMLT0LDIT4hEdK+fP7l5czfH6kt53cM6N8fju3fDCIdc+7hWxHenhOcbpblUauO+zl7Tey+3IJt6yCkUqQffyQCAAQHd2+BwW7juWwL89H4KDBGqXj89sPKOqaGDYMD/DnzFi2HpCS+fBX/F6WvW68+DOzbA5y6doSunVqDrkWjoB8v9cR+SY9+HUd/TBakpwmEX4R5ufm5BQUFeUVFhUVMpgZTU1OTpaWlpW1sXMWkuoWxmU1NU/MuDWp01pRcmhHfN0h1CAsOgcfPXsKla/7w/EU45OX9cHmQoSlZQGXzbSwtbVi9agV4TJ7KBQCYsPbkrDv7F6dJe+bf/4YPZ7zHDABgADCYZSKAzRs8YazHDLUnAGyyl7ONX3fWjqRoIoP+eKNf375y9p81fzLF69arj/5buxy9j+R9218nKZpYT9wf5LKw/D70TzGN6ZtNpmzxbvc09uPakvegzHh0/vQh1MfZ6f9dDxnGLZo1a4YeB95BJEUTvo9eTSutrwv2XesmEArOW9a0LntfJHGJlcsWIcnhLBwDwO337dbz6NkkRRPe3NPI0MhYjn7+z4o/Ypgrehxw7ZvS3494O3/okoM2ivx252mbTNafvT+ohAy+8F+htauWoOqWNWRLBD88a8b0aQihLB5J0cTgeXus/ub7+3CP/xsRSwhgzqwZCCHEwwSA2/+1XlM2GJAUTaDiNN6wYUPlG+D7QQGmTHJHVHw4Iima+CSgTo1dc6qZKoyH87RNJhcCwz3EK2Y27/TxA6hxkyaytYYkz7KtUwcF3r+FSIomdlzguf7al9m7LjuQFE3Utqn373MCgCZMGI8JALf/bzO3XepMUjTx4mkgsrGtI8fI+HfFHz3KDQkTIxFJ0cSNkDcznCatN1DV8Vm8/4Zjyb2GsycPo1rWtWVoDXx3M+bOnYMEQuo8SdFED3dP1o+r/w1fonzEA4BGjBiBCQC3n9vBG084JEUTu3fvkO+NPMmzO3TogF48eYBIiiZuPY+e3X3CalZFI0qEsnnr1qxGDKaGzN2C5s1boOjwJwghxOOsONFkymbvdiRFE/UaNC7fewDQoEGDMAHg9r19SCYPkxRFjB8/Xu774UymBtq5feu3QzGqdq/+X85ECOKjzvfq5SQXa2Dnjm2oBN7eF8rvdgCgXr16IYQQr8fEikO6mADkeJkkN530a9++o9xN/jZt2qD4ty8RSdHEvF1XHNRlDIPfxa0kKZo4ceww0tHVk3lsYMTw4ejD+/eoQ8cu5Z8fANSlSxeEEEK9pm00xARQSVvPSV56JEUT8bFRR7/7sgy5Kf+s2bMQSdFEXDJ5uPt45SbQkEfz2HCuNUnRRPLH12fatGkrc5dAR1f/eyS/nM9r1bo1Qgih/nN2sDEBVMI2dPFBG5KiiWePApCOjp5co/wMBhOdPnkckRRNHL7+bIy6j21JHoQZM2bKkASYMiWUxk2aIIQKkaK3VzEBqEDjrDrRhKRo4vaNK3Lf4jMzq4qeBvMQSdGE2/Kj9SvLGB+4Jg6oHjl8SPVuRgIgW9s6CKFMNHrNySbqPA+4MMgvGL36ZJNtM/sve/TwPme42yj5HOdFCABEYG1tA0EBd05oGZhqj/c8Pt3v4NIMZXyz05T1evCnI+EMBtw7vFLmxUKmDezAnbiBG7Nh0hB4WMeWM3DIUMjMyJDvnYkyIDc3D6A4H/R0dXTxUeBK0txWHK1PUjRxwfu8HIN94hWmYaPGKD01+aoyj5vO23nFoWTPHv0ZPJKiid7TNpnI5dr09M0mJEUTMa8jkEU1tmokRwFARsYmCGUno3l71ScQi10AKQTx6mVfOZqkzG/Kn/NV4Kfss+YkRRMXiBOoTdu2qG27Dv/f2rZFbdq2RWn8SHTtWdQ0efWj+4SVTJKiiZRPcYR1bVvJ2DOVSgBa2rqoMO0jWn1S/inLsAugAjjpOWHvuzeRnMFDXOV3iw+JwLq2DTx7dO9aej4zSxVumr179xaeh4b+9TdpX76ApnY1lrz6EHDCSwQAowU0EGFPH/q27tjDNSH+g+QGH0Mp41KQnwuFhQVQRV+9XQBcHVhydfQzmSh06t1PjspfDEbGJhD0wO9EbjErS1WumVapYvj9m39tJfkFWFqQk1uYJ+++sC3MRxcydfNCgu97W1rWlFzNVR4KCvLB0EBHDxOAmiu/DuTpde3Zb25hQYHclB8AwP/2DdAyMNFW+zvm5SQBkaZ+cXCg/zFDI+P/y3ugSGRl54CeLouFCUBNEfQmbjnbwtCqi2M/l8+ptPRJI/5B+c+dOwfWdepzx3kenYrVvHQS0DUy173vd/OnMVQ0MjNzQF+HpY0JQA3hecK/b31zo8b9+g1xeP06Sj7+psSEXbZkMXR37Mmdu/vqOv+Dy7OwipeOMasOT7ayrc+9eMFbaSSQmZUNVfS1cAxA3TBhPWE3rb/9qB3btnJu374tUXx5BJsQdOniALPnL+T6PIq96b1hUixWbelw7/DKnBnbfFZ06daDu3Xzxp8IVVHIyMoGAz0tI0wAaoaNk50XPg68x9m6dav4H+Rk+lcxNIa7ty/7J6RlfZjl2skbq3XZ4LtleuLBWy/PjR4/kTtixAgAQAAKzGGZmZUDBiyWISYANYKAFhJ5mV9zh40cK1F++Wz3AQD4XODC1xxRavsGNp5Ynf8Nayc4334YlRS4e99u73r1GwCAIqwAxjcCMNbWMsEEoCY4fS/MncFEGs59B3ggUbGclF98jmXK5InQwr4Nd9oW72VYjcuHkY4tjyERszjo3jWxciooHpCZlQMlWZExAVRwjFt3uplzi1o9li1a7BYb+04+Zj8AAIigalUL8Ppvw8Wg6OTAK9tm8bEKlx+jlu0ZCzqm3BPHjygsHpCZma3241ppCGDz1L5LngY95Jw8dVp+ny4RSm/iBBQXMwuHd7M7hlVXNgg47iVacfzujj79B3EH9O8HMqk/UIoLkJGFCUAtEPnx0xZdDZHByDETfvD75SFACHr2dIImLdtylx/134bVVrY4vozz8nXSl5c+3mfv6ekbSFwB+R0VzszKkRREwQRQYTFz+6UO1Qx0LV2Gug3Kz8uR3ydL/FLumQPeCZ+zPpxYMToCq6zs0dO+wY607CL6zIkj31wu2RsA2AJQG6wc03XGzWu+nIeBgeLVgiGf/X4AgOlTJ4FIw6i4fSMc9Zcnlh7229apW09u9+7d5RoLyM7OxQRQkREWl7hBm5mrN3X6HAmzy2v1FwGDqQnbt6z3fxEvfIpVVL44tWpMRMLnrA8Xzp24CMCU265AXh4mgAoL9/WEXQ1DPevhoya5FBcVyPFTxav/vFlT4WsuI7V/u8b7K5QAMCrm/LZvZONZzNQv9Fqz7Kd5kCVyc8UXIB091rAwAVQw/DfZeeGTRwGc+/fuytH0F6/+wNCAdWuW3Q79SD2uCGPjOHENa8DcnWwAgCKkIRVJFBQVi1TtO648i7uz0nNVkHk1S7m4Anl5eQAADixtXQN11RO1PORw0u/5uAk9G1p5TJ4pX9NfggljOZBZwEob2L7pQVUahwFzd7Lt7RrbD+rW0MFST68mgLjM94PjawAAHAAAcgrFxMhgMOCPpeKZLLA0MzCTd3+dp28yZDKYGkiymjMkEf4/lQSfNrADV0AL+xzYsxmGjRgjsQJkR/S5uWIXQEtbRxcA0jABVAD08PBknftvptPc+csc0r6kytfIkfie6z3nwQdhxlu2hbnSv3/VMT/n6QNbjWEAwI1d86xyU2MdIqPCISCeD2/efYBEPgkCOhXSvqZDbk4epKam/uVEJBMARJDyFaBhbeNmSRR96uC1sPMbJvfxl3W/H7/5sPL0mokN2RbmnF/+ryABLeT/KYfCmlMBe9eMd4bGTZpzot+8kunpzty8XAAoAB0dXfVNCqJuOc4iPiZuiX8XJb8iHr/kjuvcxQGRFE30mam88l3uXoR9iqSMGMrm8+5cOYumT56AGjZqgrS1dX8u1/27VkoJrlrWtsjdfSLyv8ZFKCeJV1KybPJ/51vLov8XHoR7CD+TF3r2dELNmjdHzVu0RM1btETNmjdHrVq3RQiRvOVHbzv/Lbfhk8A7sp1zAGRjY4sQSkdj1qpGFWacFLSUNnLV8UYkRRPduzvKP8+8pBCF/7VzSFnJPRfsvtZN/O5CHs/PFw11HYKMTUzLruRlqFRsYmqGhroOQQ/v+CCE8nkkRROrj/174sySTMwT3Cf8kaCK096hdWfu9f/TM0asOFKfpGiiQ8fOspt3AMRmWyKUT6MpW73bYQKoIDX8gu7fUNjqb2pmjhDK4S08cN1Rkd85Yc1ZO7HiZ/GOHtyJGjRoKDtlLwMZ1KtXH+3dsQmh4lQeSdHE3H+oZUhSNHH71tXf9x0AabK0kSg9Dq08fse5tOe8eHxXpjUHjYxNUHEGHy3Yf60bJgAVb7N3XXaQSWnoMgjI3DkzFL76x5OCoyRFE+fOHEW2trY/KCTjHywY5r/X0fuhFFeNGjXQnh2bEUK5PJKiCbdl0lU4uh0SPbswS3jf1NT893MGgJgaLFTwORatOXW3/9+eVWIFtJeVFQCAtLR1UG5qHPI8pb6pwdVq9T9/9phicspLSlN/jApGwTFxKxVZWDMlIYbo1av3D4ov/Yr9T60MVkH9+vXR7es+iKRo4nLwq7/WERi/XmzFuLi4/Pk9kn/PTHmNNp57MEgaGQjhySgWIHlGeko02n6J54rrAqgwdvkEDx/tWI81f8layb/I+3QLAtu6DcCmaaeg5SuPXey0vo5c33bsVugYL4+eztevXOLMX7AYsrOzJGcbmH/dnSiBuUU1qFOnLjRvUg8a1bOFGpYWYGZiDFos8fTnFxTC57SvkEIK4V1cPLx5+wHi4xMgKenTz8/6U4SdoQGAEMTGxkLfgcNg1CgOh3tyl5WAFnaavf3KmoubJ8f9+icbJzkvDPC/xbly5Uqp88VkMkEkKv2gz8L9Nzdum9EfmrWw50RFvpTJPBcW5INRFfVNDa4WBODWtcHAKxfPDydT+HLf8y/BuJEuIKCF/PPrPeSa5y8y4dOW/m1sLD1XreIcOXL474r4g7LWrVcfRg0bCC79eoBd21YAmhZBAlrIBwAoRKgoq7AwvaC4OB8AwExDQ7s+i2XEkiS/EN+AS3d4+/IlBD99AYTPbXgUHAyi4qLvBPvrODMYAKABgIrh3DkuBAQ8cDiwdyfsWeACOy4GXZk/3MG35Kdh7xM32FRh6ozzmF76OQ0kgsKiItDS0ixVVom1E94IaCFs8lwA/YZwJIe0yicPOTk5YKCnp76ZgSu6CbPnUrAbQjm8qhbVFeT7i83/xJgnKDhavuY/X0CdQiib18Ox599NckmfAAD1798fBT+4jhAq4pEUTQS/j1s5dcuFdj0ne+lJ+94eEz1Z49adsfN7GTO7ZMvvS1IU2rF5HaptI0Xc4Yf4wMyZMxFJ0URsUvIBhBBM3+7TgaRoomvXrlJsQYqfQX8MQ3uuBrtJ0/eZOy51Fgip8zVq2ZRPHiTvfh16D914/mYGjgGosO9/cO8OxdWTA0C1atsihIp5I5YfkVs57xSKJkR5X3h2Le1LUTaxoLZp2w6FPLqHShTW3Yuwl1VfnKasNzh7L8xdHPDM510kjqGGjRqXHif4oW+fyQ+XJEVIeTt3bpduviR/n5oQjnb6PhpeFpnYt2tL+WIBknc/C7iGAl7HLsIEoILN87hfX4TyeebVLBVXXx4AzZ09Xa7R/3dJyQdQUSavWfMWUin/2jWrvyn+sMWH68pzzKdvFq/gCBXy9uzchnT19KWyTsyqVkXv3oQjMinpu8UipRKmxIagg7eecKTt48EbTzgoX8jT1TP4d7mQvPvu9XMo5EO8FyYAFV39vc8cVuDqLxbc0IfX0DuJSSvrdvaBeKXt1EmynfWnbToAZGhojIIe3kUkRRNLDtxQ6FmEebvEpcUzhR9uuLq6SmUN6OoZoBpW1mXeXUiMfoKO+YeMKatsTJs65e9jKMVc+547hqL5SbsxAahYm7LVux1J0UQta1uFrv66+lUQyqfQwoOyP/wzc8elziRFE6M5o0pd+S1r1ERJ8e/OkBRNDJizy1JZ83A/8u18kqKJwwf3Se0SlHUV/hTzFB31KxsBhMTGewniI/79cJSEAE4d2Y3EsRhMACq3+gfc8VFsLXkA1K17D0RSNNHDfTVLHt+0Z9fOUkxqQOYW1RCdnHBBWUeQ/4+MN4rJOOrlM1SjRk3ZzYlkHOIieejswzD3svRp8MJ91iRFE63bdigXAezd8R9SlXGWR6uQ+QCGLj1oAwCwePU2Be37f4dLP0cAAHhwfG2hLJ+bRNGnctPJ3Nlz5/15qw8Vg4YmC54GP4BiTb1CVakyfGjpiJBxq45OrVrDlvv+dYi/nV1L8RacjKr4iEQINJhl28+7snVGIgDA6kVTv20nlg3fi4OoMyokAWye7bI0i/7IefE8RIH7pWIBGuDUGd4Kv0bJ8tHLDt9y0mQwNPu7jPb4s/KL33/hHAH6RhbcUcv2jFWlOfE/vDyLbWE+OiWHmfjg4W3fTp06A4BIoaW8fsX+m2FnBwwdFmRkbAr/mjEoIzNbrTMDV0gC0NfU0PfcsOPvh2LkcPrPtKoF2DRtEcS98eKBLJ88x6XtuCsXuZzoN1F/sGbEVuzoUSOhU9fu3Pn7bmwIOO4lUsW5qWPJnvLhc16M71Vf73btO4Assvbm5eWDvh6rzGm5vNx7+wvoLL7biKE/jGPZgC0AFcNJ/+fjTPVFFucvXlb4u+1aNAdBagH/6NKRL2T1zDP3w9yrGWlazV+86s+n4pAIdHT14dTxQ4Gv+J9fnFvnHqPKc9SmTu1Vgqw8/rPHd4Pq1K1X7qSdCACYDOY/ySo/Izt+yezxZXcDGNgFUEn0aVnb6eiRk05IVKTw7js6tJX5M3s1r9XD02uzQ15u1h++R7xqea1eDMKM/ORerRruqgjz1KJ2rcVkai7/ceB9b109g3KRgEgkAibz30y97afundWtWpfbsFGTf3p3pprXBqhQBDDO63QzAICte47+xNKK8v+duraHlOycJFk99sD1J25sUw2rbTsP/Pl7kAi0dPRg4YK5QZefvr9ZkearuoX5aMTSLb5zQ3IN4B9JIL+gAPR0NHX/5W+910+KBQCYMMat7FYAAOSKE4NiAlAFrJ7oPDOV/5qTmPBRwW9GoK2jCy2aN4Ebj2KDZfXUIe3r9T9+5IxDbk4m/G0nY9QIVxCk5fOnD+roXdEEbNqWiysaNG3JXbHi39N3MxiMciX9Do4lg6Z6DP+n9+fliwmg56S12pgAlAx9TQ39XftOSaRCQ6HvtrGtA1om1kEvI2Jkcc8UXBcfsAYA2H7g1F98f/GKOWmMC2QUFGZURAG7sm1GonfQu+szZ8/jNm9u90/pu4uKikFLg/nPuflPXLzrm4NMuO07dCzz3+blSlKDa6nnleAKQwCeJ/37ss20rM4pIfgHANC4YX0Q0F/413bMTpHF86aM7OFSnJHAiXkT+dfVX0tbFzp2dYBjN8N8K6qQzR3a+SIAgO/F0//kCuTnF4CuluY/5+a/vWfhZwCAiWOGldkNEBMAAi1tXV1MAMo0JfvZj7pz/bpDbk4WKPLgT8k+doc2zWX62OY1zFoT3jdKnYZmTRsDaJoFRb2WjeWhtPjNmuPTDUyqcxcvnFdmU5zJZEKxCJXr4NXN8Hj/MaMGS2RH+neLU4Png44OtgCUjiOnff9sLsvR/wcA6NimOVC5uTJZ/XtN3WAAAHDlluQ4wV/4rEXThgAAcGff4gpdmML/wNKMO2EJ9zZvWhtkWrVamVbhwsIi0NXULFd1Ht8bgTfT8vW5HTuWzQ3Iy8sDEOWDrq56VgeqEATgdfZ+/2omTKvbfneV8HYEDAYTGjesC0Gv+DJZhVu2bNHOTLeAExVV+oHCWjUtoSSTT0XHhD5tTgs+5/G3/re6TFZAQWEh6GlqlmsFLiHQ0SMGlckNyMvLA8jPB11dbRwEVBYmObdwu3n1ukNBfq5izX8JqlvWAGO2FYS/in8ri+e5OjXtFvP6FeRkZ5b6PSYmRmolcHuuhJ7uO2gYt5a1rdRKyGQyoRiJyl0C2D/qU8CYUYPKRD55uXlQmJ8HVfSxBaBUcH1uK8H8F8PKygpAwzgoOelTnCyeV8tA3yYk7I1U36OpqaFWAvfflH73AAB2bFz5U4zlb8gvKATdcloAAAC+t4L9DKrWD7Kzayn13+Tk5kJ+QT4Y6OvgIKAyMG/fVQe2hZ7Vbf97SutDXdvaIKCFfP+Dy7Nk9cyXr6Q7zVtYVKx2QrfV5+mxzk79vC1r1gZp7goUFRWBpiRhaXlwfcecFAEt5A/u30dq8iksyIP8/DwwrKKLg4DKwLRBbd2ePXzgkJmRrgT3Xywgds3qy+yRPdxXMdkW5lbRsdIdZvr6NUPthG77jIGBSMQo9lw6SypFZMjwxGeM4GvkWE4/yX9J54IU5ueDiSF2AZQCQ22W4YUrkuAfQ9HmsFgwWzSpL7MdAAOjqmwA5EDTqVL9np+UopbXUa+Ext2ZPGV8kL6B0V8UUaz4BQWyS71w+vqzezYNOwTVqCn9kObn54GhgRYOAioarosPWLMtzK387j1QUg/EBFDfthZ8pNLjZfFEs6pmFoDSITNDupU9PErsKvSZsdlEnQRvWv8OXMGXYv74MaNKtQJEItndfD61ckyEgE7l93XuKcWvxQSUkZUDOtqaLEwACkYfx9YOmalvHd6+fau0PmiytKBaNQt4E0vJZCvOqIq+oSg7C7JzpLtlFhX1BqAo1aFFiyb26iZ8scL06OULPcpkjssC2UXF2SMGSQhAilOJmVnZoK/Dwi6AotG/pY3z1av3f2JjRaN6dUvQMa0GHxIFMrkFWKWKrm5uTi7k5+dL538W5MGjBzyY1L/1cHUTvm3Hb51iGlhx7ezb/HUFzssvkOl7zwW8vuHYuxdoSLmoZ2blgL4OSx8TgBJwL/CJRBaU09XqbDYA0zBIQKYkysSi0NBgFYtE0pm1kpjHvuMXQF9TQ+0E8PqOOSkAAHOmSFIb/uFcAJJxWrFHwSGBgjTE7dK5k5QEkA1VWCwTTAAKxMhVx+qzLapaBQY9UWo/qluyAUC5R3F9fK+AoU6xyZ3nMbPVTQBvhsf7jx01BFgsLfjT4RxZE8DdQyuyAAD6O3cvNf5QYgHoyeAcAiaAMqB7p2btsgSvHfj8ROV0QCIU1jI+iltQUFTI0tAADQ0NqacIiYpg0RLPvi2tq7Z1nLRGrYJR3r7+vnSONteha7ffWEBiFyBfxi4AAEBkyudQ1wHdS4k/fE8LJotzCJgAyoC+LW0cb/o/Vqr/LyYAtkyfl56RnaFbRQ90pb1dKlGCA4eOQH4GzTm9fvpRdRLA+0dW5QAATBg1+I9uAEMOmZ8u3gkLrt2kfdB3wi/+/yYhhvfvP4C6QmVZTZPB0Ax6Fq5E/188+bVqsiG7qFhmieG+fM34CjrGYGBgAJ9TaSlJQFx2u1f/YcAL4mlef/J62sCOTQ+qTSwg7KO/u2tfzrjJLCgu+v89/6Ji2Z+GPL6M81JAC/k+3KPwPCwKfptzFAEgJIK+zt0wASh09Z+1zez23oVWL8Mjld4Xays2fPqaGVfHUjaWQNpnoQBAL8jY2MShbM4NE2LfxcD8uXM4O3bthpN+z3Mm9G5zWh2E8PLNwJsDW7lz27Rpy3n29PH//f/ycAEAAI7divT26DcIho7y+OOpoBL3b+7Oq+u8N05SPwZQxXJFiw5ed0QiIdLS1lFc3b8/lKUi34eWuSyVFI03eNCgsn+bpFzV9Gni6sTXnkZNU5cSVSRFE+vXrfr/mogAaNvGtWpdnguXBvsFnVrZ1E98/QYK8pWbkZWpwQJjYxNITEn7LMvnCmgh375Fo7L/ocQVOnDwAMyaOZMzsL2tm4AWEr2nbjKs6AvRG8GXl2Ncnb7b3j+gsKgQMCpRELCddbVOgc9eKb0fxsZGoK2vDwL6q0wJIF8kyu9YkmKsrFtckrMBl3wuQvPmHRwyhImcU+smHth/7YlbRRZEn7sRj2s1bh3EZGr+HJQDAEogwJpa2YKAoeFvfhJ45RCAMTB0q0Da1wyZngG4Hhp3b0I7e3cmUxNEoiIA0PgnEoiKegUNmraBRQvmcrZ4LbYS0ML+t17G+3N9bnkHyLh4qbxxaOGIEAEt5G/ZvB5CQkK/fSMSFUMPx25YUytLDMBx0jo9hBDPsUcP5fn/Et/Tzq4lQkiEBs7fbSnLb+w/ZwcbIcRr0qxl+b9REqswMTFFa1YtQxmCGERSNEFSNLFg77VuFckf9X8WM1fi6/N+bCRFE3suBrthn132TeU6NHrNySYI5SFr69pKJ4Cu3bohhBCv52QvPXkEvVYtXyJRYKbMgpZa2jrIdYgL8r/KRaiQ4pEUTSSQguNbvQNd5fEduGECkGlbT9wfhLITEDCYSieAAQMHIskqJPPvDI6JW5ny/vk3xZX17gUAIDa7Oho6dAi6c+UsyhDEoJLVNOBN7KKKZh3gJp+mcjGAxvUsLGPffvinCjKyhomx/BJybj/ud/bAouEN7Vu147wMC5Hdg3+ImQgEJFy6dBkuXboMWto60LZNGwfnHp1gcN/unG0ebYJKdiQiyc8vnoQlxj4NfRFUck4eo3KAIeuLFuXFxxTB4fDAm5OHciYpLwiIEACIYPbMabB774EgAOgqj9cIaCERFuzP6e86BgAY8jvxKPmeH2FubgF2dnbQpYM9uPTtBvXq1wNtE9sgAS3kp+blC5/FpLwMfPzmJbFuwhusJngXQGHQ09TQf/+x5O4NQ6l9MaxiAAJayGdbmMvl+ZvOBx9ZOrIX1Latx0n4+F6ONM/4vtOAAABEIBTScO/eXbh37y6sXrcJ9PQMwN7ezqFJ4wYwwKkzuLazAw/nEUElJ+GefBQ8Do1IjN00tf8DrDaYAOSKuHgJATCUdUxBbBWZGFWR61t2zXEJEtDCyUcPbAGn3i5it0fe38wA+On4BxKHDHJysiA4OBiCg4Ph8JHjAABQt25dh2bNmkHndi1gYO+unCHurYMAYLWAFvJDE6jHT8MT4zZK0nxj4G3Acrfu7iuZCCFen97OSg4Aio/cHt2/Xe5HUEeuPN6IpGiiT99+stsRKNe3M799/6/N1NQM9evXF3muXILeht1HqFi8y0BSNHHML2TMyBXHG+HAGt4F+Oc2YN4uS4QQatWqldJ3AAAA+RBH0Luk5APy/m5e5PvlWenkLQMDQ+V+919J4feE4Orqgvbu+A99SXyJECrmkRRN8KLfL1+477ojVjB8F6BMMDU1tQDIAqEwVSX6Y2RoAF/y8oXyfo9D87r/ZeZppF2+dE5ilhUrPf7xfzEEhsb3JhGbL18+g6/vFZg1fzmYWttD8+YtHLb858Wpkha7YeuMrqsFtJB4n5xyYO6uKw7Y1lZNqBQBWFYzNYe8dKAoWiX6o6enA3n5RTmKeNeMbT4rmrVsy925Y4eEBIpUV2r+jxDEZBUV9Rp27t4L9p36AZvdwGHNyqUc+u3zabvm9vYS0ELiWsjraS7z91phtcMxgN+2PVeD3XIFb2R/OOYfXYCwR7fQ7ZfRsxX1/ZM3nW9NUjSxdo2n8sdARoeRAABZ1aqFFi+ch5JiQ74dU56y2bsdNsFxDOCndvZhmHvim2CVIYDo5/fR1RDF3rmft+eKA0nRxMb/NlRsEvgDGTg6dkc3fYlvpxKXHrzphBURxwAAAMDcVM+QTv2qMv3R0dGGvHzFXkbfMWtw0IazQYfGT5zEPc89Awymxk9XYyscfnIVAB48eAj9XUdD48aNHR74XefMGdJ2nIAWEkMXH7TB9ngljwGwjfQs6c9pKtMfPR1tyCssVviZ5L0LXIPn776xoVvP3tyP0c+hQ4cO34ODKnZy85/IAABiYmJg9DgPcHZy4ryNeMrZt3Co183n0TOwSlZiAjDW1jZLT89Umf7o6mpDfr5y0tGc2+AeM2rJnrFgZHns8tVr3H17doCxsQkAiNSKCF69ioTuzoNgxtTJHKe6+oMEtJAYtvgQtgYqIwFoM5naWdm5KtMfDU0W5OQV5ivr/QEnvUS12dUmbbvw9JjriNHctJQ3QQvmzwUdXb0fiKBYLYjg8pWrUM3Gzikk+CFn70JXr23ePFesnpWMAADEZZgk0qES/REhkdI1bNusgYFsC/PRl8NSvRcuWc7NoWNg9arlUL265Q+uQQW2CiREkJ7+FQa7joBtWzZxRvdo7HKBF+GBVbSyEUB2jmoNEJOpoSp9GdK52UHO0n0TTj2mxk+bOZebkvI26MyJg9C1a8k5G1HFJgNJ8Z3t23fA1MmTOD2aWjoFvYlbjtVUflCpy0BsC3OroqJilbAAGAwmMJkaUJCvWilpH5xYWwgApwHg9Iqjd5xnDXLlO/VzBUZWIufAiUtw6coNiI6OlpDBDzzPYFQAcUTfiqBcu3YNvnz5MvzyVR+4H/5ufs+WDXZgda0EFkB+gWroG4OpKSYAFc5JvWFSH3+2hfnoKRvPL35Eak2ZNnsB982byKDY8IeweMFcsGtp9xvLoALEDCQuwaNHj2CYq9vwpjVM7Y/cCBmD1bUSEICoWFUEVHIGh8nQUPVJvLZzdsrQTs2PsC3MR0/d7Ls4TlRtzrzFy7nhL8ODkmNDYNP61eDs7Py9HuFPNfBEKi2egYGBsGThAs7AdrbOiw/ccMQqq8YugNj0ZuBZKQcOLRkRAgAhAABuy4/Wd+nbxmHcpJndlqxYa1WUHu/wNOQlnLl4G15FvYbQ0FAx0f1kFTDF7hdDJYQBADHgzNmz0LF9a878oSMBAHBCEnUmAFSR97dVDN7/TYoFgFgAOObosYbVzaGzcz+H1p29/nOoybYwt/qaHOUQFv4avK/chVevY+BFWBiIiou+G0CqED9gMAFQMUydMQecnRxzkxA6VbOaxXg8u2pKABoaquWVIFFF3mj/jgfH1hQCwE1Jg/5zdpgP7t25d5tmnZp5te1pybYwt0pPeePw+s1buHrnITwJiYDwiAjIzcn+uVKXMjwiSWBwOGeCx/Wbt7hTtni3PrzY7QVWXzUjAAEt5GtpaamI4hdBcXER6GiztNVx4m/uni8EgLMl/91n5haT7p3bduvWtpX9gqUONlstzK1yUt87REa8hht3efCAFwKRkRGQ/2u9RoURAgOeP38Oz3j+nLXjnQEARmP1VUMLgMUq6RICZTqiJbelNDQqR0zizr7FaQBwRdKg19QNBp06tO3Wv6t9h9nNO1v/t8XcKot66xD6IgJ8rt0D3uMQiIl+83P8QJ5kIHEFZs5fAWHhvTQWHLjebfv0gYFYhdWMAAwN9FUpIKFSB4EUCUl9gG8uQ+/pmwy7dm7bfWhXB2fPNo6GbAtzq4+vgx0CH4XCae9r8Pz5C8jNzZEzGTAgOekThAT6uy0a2rsYADABlBMqtw1YxUDvBwtAuSguLgJdNXUBygq/A0szlo3qca1eDcvpbAvz0UMW7h8bmWE0va/rGO4Fn0vcL0mR4Ms9As7OzqCnZyCfcweSjMmeG3cDAMCQRfut8cyokQWQJxLlGujrqUx/cnLzQVtbkyXLZ07bdrFdTUszdklwseScQUDAo9uSQF2FwOVtMxIB4CAAHOw1ZYNBH8cuV0b2HOzSsedgqKqdxTl7/iocPOENz5+HficBGVkFES/DgJGbwpkyyjEUAPZgNZaBr6sKLSQu3uvejfMqkxEoNjwQ+TyOnCyz7L8v3y/PyuHfQtnxCGVJWnY8QnmfEEnRhPO0TSYVPcNMr8kbDLaeD3QtSf0V8eweGj586M+ZgWSQsn3d6hVyT9mOMwIpGIIvWSnVzE1Vpj/Z2Tmgp8vSkdXz6tcwajx72pK+DH0bYBjYipu+DTB0a4NOfgpnrFuvCn8F1v/w8qyFbl192Rbmo2duu7SqilXTI7v3HuC+iwyG/v36SladcrgFEjfgpv99ABDvXuBlXE1iAGkZ+fnVqhqrTH+ysnPAQJdlIKvnsS3MrQoKi36IcUjiHEgEYRFvoEfDmt3USbgubZkWb2vJnjLR68w8hpnNwaMnTnF9vAkwMTErd3zg+fPnwDYp4rRr06IDVmM1IQBSmP65qpkpqEougKzcPNDXYcl0W+LbOYdfcuUFPQtXWyG7tXeBsF4Ny+kL997c2Ll7Ly7//cvbPXo4lssaQCIRhD99AU7t69pjNVYTAuCTX2imoTGYmKqGG5D2NQPMdHQsFPGuB7xnwLYwt3L0WMNSV2EjvCa8YVuYj47Lgjfc8+e5kyZN/kcSEC8QAU8joI6JYUOsxmpCAELhFyEwjYFdrZqSeyIWMGFqGugwmbqKeGNEZBRAYapDsxbqb9K2sK61+Przj/7r1q/nTps+XUICZdj2lcQBomM/Yg1WJwJIT0sVAGgGWcipHHeZCUBhGYoZkJ2VDuEhz2CKS9tKkQtvcr92Z30ex95c7bmG27dvXwAQQVnPfqQkk8C2MLfqMdGThVVZDQjA/+DyLAEt5NewtFQRAvgKbAtz+ZeyKkmMeYsHJlpaZpVF+Ga5dPL+QGe8ve7rHWhkXLXMuQk+f/kCAOCgb2hshlVZDQigBHVsrMpuFspe/+FzWoaCXij+Tp9rfsC2MLdyqUQn3Do1rbNemJGXfOb4PslQSE8C6ekZAFAA+voGhliV1YQAEAA0qFsi/8rNVpOeng4AAD0mrlLIOL2LeQ2f+VEOnMFdnCuTEHqeerCrbece3CbNWpTJDSgoyAeAAtDS1sLHtdWFAMKTU0NbNqmrEn35nJoKAMjBwKgqW1FuwFnvq9C5XvVKVU675G7/+pXzymQFFBYWAYAIWJqaOAagLgTwMjr5Y+Mm9b5FepWJ1M+pAKIMMDMzs1DUO4+e9gEAANfFByrVRZfDfhHeg4e7BBkaGkttBWhoagAAE4qKigqxKqsJAbyLS4oH/RpQy6qW0vtC06lQlPkVLKuZKWhfkgHRb6Ig78tHztJJfStVUQzPsU43BXQ+/3uNg9Kho60DAFqQn1+Qj1VZTQgghZ8QC6AV1LBBPaX3JS83GzIz0sG6hqliLACJ1bNt9wmwMtKvlPXxunZqI7UbYGCgDwBakJubm4VVWU0I4MGxNYUCWshv2qSR5F+UmxcgmRSAVXVDhV44OUl4A9tU02rbxcpVH+9TZnZ8Gzvp593UxAQAICgnM/0rVmU1IQAAcV6Ajq2bSb0SyMscBwB4G5sIdc2NFHfclMGEnKwMOHrklMPobo1dKpMwxiR+jq9Tu4bUvzc3Fx8Yu3dkVQ5WZTUigOC3yU+7dmyh5F5ICCAuAaqwWIaKfu+a/3YCg4k0lh+55VRZhPFrRm6WqYlR6T+UnA+pbV0DBLSQj9X436Gpip16FBr7anS3gUFmZuYOnz8LlaT/DAAE8C4uUTGnAX8hgZRkPjy8c91t9uBBxQBwrzIIY2FhcbG2VFmhxVahXZP6kC8SyTQAOHjBXqsh/To6IQAQiX5fGZrJZGrExQuTvSb29scEIAccXuz2QkAL+e3atoLbd/yU2hd+MgkAAI4ea1gKS9klyYA7f+laCO8zUGPtyXv9PSc43VR3AmCxNDTKEtDv3LYpBH8gn1qzZbNJM3r1ySbHVgxfzcxMHi42Mv6cwszIvt6Dl28Tu9s3tF6KXQA5oW3rlj+ZfMpAUnISAOQ5WLBrKjYqz2ACmZIEF86edJvSz86tMlgAJoa6Bqlf0qX6rUEVI7Bs0BQeh8XHyur989x7jKLiIoab1W4FVW3+3uYu3eBoaapXE8cA5ISEr1kfBjt3+snkUwYS4xMg/wsfmjexbaSMGMSCpWvAWJdR9UHku/nqTgD1rUytE/ikVL9t364NCOh87utXEU9l9f4aenrWEa+l4xO7Zo3UYsxVlgB87kc9bNGpE+jqKjNLMAOKigrg48dEaNOsRh3Fv54JRQV5MNZ9qnOT6qb2o1afaKTOBFDbyKBO5Ov3PxHg/0GyK9Sre2cAAHhwbK1M3bLI1+8kr9f4fZOoTP26NpBdVJyNCUBOiIwIfyqgC7kdO7T/u0AoAC9fvYMG5ibNlUFAAAA+l3whKuwpZ8fMASvU3QoICXv1PQ7yewYAAIBxowbCi09Cma3+PSet1WZbmFuFRbwp5ZdiAqpV0xKevk8JwQQgJ9w/4pkPAODsKDkaqpQanWIFfB4RAywGQzkBU8kloSEjxoCJHsvi+bsEL3VU/PHrz9qxLcysHgU/LXU+GjRsBCK9mtzTvkG3ZfX+6jWs6wLkO0RExZT6Wz19Q7CqbQXhb5I+YgKQI158Ej7lDO/9E/MrVvkYErPwrXIzzzA0ICszAwa4DHeyMtG3WXv6Xn91I4BJQzv2//Q2xCExMf7PP5IsAtM9xogto41T42X1/i7tG9mnJryGL6lU6bGCGjVAQ79mUFxcQiwmADnikl/YY8u6bYNq1FTuxaDo6GiAoq8ONnXrN1NeOIIJ9+7fg/1793Cm9LFz46xSr3hAHVPDhtv2nyvd/GdqwNSpE+7dffUpQJbvH2Bv6/zs+Wup3M1GDesCAAOu7ZidgglAjji1ckyEgE7lD+ir3PwYNEWCID4WenZprMQU1GKhXL9+PQTe9+dsnzVgxaB5eyzVQfmP3AoZwzbTtTpx+uyfFVCyFew+ZjR8ydagx/ZsdULWo/v0RUQpBCRGq+aN1OYEIlPVO5iWX/B54phBSo8DhL58DZ3r1eis1MGQxANGcsZAXEwU5/CykVv6TN9c4SvjDGxj67xl6y6H7Mz0v6y+4uDbls2rICE164Ms399r6gYDtoW51cOgZ1L9vmUz9clErvIEcMD3mU/rzk5BxsamSh2i+8HPlRcI/A0JdO/ZB6ikeM7JNe57+8youOWxbofEzDbRZ1is8dr8l9VXvPpPnewBhQxD7vIdp9bLsg+NmzS2h6LPDi/CI//+Q8kCZN+iETx8lxSoFgxQEQoYkhRNTJwwTnkFQwFQy1ZtEEKI5zy9XAU8ee7jR8vmOwCQto4eevEsGJEUTQyev8eqohWmdN9A2JMUTYwYPlxSJ435x2/V0tZBBdlf7t8OiZ4t6348ffdxbeTjW6UXLwVAZlWrIVScjsavP2uHi4Mqyg3IK/g83WOkEt0AgDevo6Dga4JD546tOqnEoDA0ID8vB9p26gZR4c85B5e4bRy75nSzirLw9Jjoydrg0Wv+g7v+nAsXL4pNf8bvfH+x6X/04B74nFUk6NO2kczLgdc2NqjjFxjyk4X15wBgAwCmYdCn+Lg32AJQUJu8+XxrhEQ8dvUayrECgIkAAAX7+6B3SckHVMIC+KWU+cnjxxBJ0YTncb++FcWqi34VhhhMjVJX3Z49eyKSoon5e691k3U/nKasNyApmnDo0qX0eQFAi+fPVquy5BXCAhDfDkzlu49x+8knVHQg8Mb9x2Co0NwA0scEJkz0gB1bt3Cm9rcf9fpT0k5Vnk8BLSS0IFenm1N/QKLiP6+6qBgMqhjBDd9z/snpOYnbZw6Uud/dqpVdB7YJg/P4WWmH+sQy5+jQVsk5qipZELAEsXR69IwZ434yCxWs/3A3IBjYFuZWKleTXqJAW7dtg9EcDsdKp8hGQAsJdy/CTpW62dNjrbaAFhJaKFvHvl03V5oi/6r8AAB3/a7B1zxIbVXPWi7HoCf1azX00UMeFBcWlKL/ImBqaELH9q3gcuh79bmaXVFMlb6ztpmTFE107NhRSW4AIE2WFspOjUM7Lz8arnAXoLQAFUMDATAQACADA0N09vQJRFI0ERafsEkV5m/smlPNSIomoiOfo2rs6qWa/QCAjh09hEiKJgbO220pT1dkzsxpUpn/DRo1RQiJeAPm7rJUFxegQnWWpGji2sVTEgFhKJgExHGAaxdOlMcH/DcCAED6BoZIW0dfur+VKJDLEFdE899dICmaOHzz2RhlzRs34KUHSdHE2TOnEIvFkkr5vdatRSRFEx4bzrWWV79GrjreCCHEq1WrtlQEMGHcWLXy/yscAXie8OuLUDbPxLSq0qyA4cOHKZYAJArx8sUL9DoyDJmYmv59y+yXv9PR0UErly9FKDuZR1I0ccI/dJyi5mvm1kudSYomUC7F8/CYJNU2GwCg5cuXIZKiiXm7rzjIs39+YTGzP8U+k6JfYsvqxsUTmABUwQpYu2qJZMKYCicAY9OqCBWn82bvvuwgdwIoifCfOokQQjyEEO8zGX+pU0nEugzWQNWq5mjN6hUoNzXOj6RoIiIhccuk/87LZXXd4xvsJlaUPN6Rg7sQm82WWvn/27AekRRNLDlww1ERsvTf2pWlyxIA0mRpo+zU92jfjcdumACU2LwfhntkpSZ825pTxnZgaOA1FE8KjsqVACSrzhrP1YikaGLE8iP1EUKQQAqOkxRFLF+2RHoS+EHB9PUN0Jgxo9GLR7cQQtm8kjjBRu6DQf/q2w6Yu8ty39XHbrFJyQdIiiZQViLv0N7tqGHDhlLGLsS/OXH8KCIpmpi7S74rP0IIhi49aENSNNGwUWOp+mffqi1CCPF6T99sgglAia2HhyeLpGhilNsIpbkBkydN/FdTUEoCEBPNmDFjEEnRxMqjd5x/coWO+/UlKZp4/jgANWnarAzWAPP7bwFQvXr10UT3CSjI3wdl02+/WRkkRRNxyeThgNexi3weR04+/eCF+4l7oeNO3Asd5x0U7uEfETM3KpG/k6RoQjIOvGw6Bt2+fAaNGDECGRoZ//AeZqmKX6tWbfTiWRAiKZoYv04xJ+z8wmJmJ394IYVlIu7nqmWL1M78r5AEgBCCF+8TNiS+jyzbCihDAjA1s0AIZfHmlN0NkIIAxErapUsXRFI0cfj674N3zlM2GooFMp+31nMV0tXVK6NFwPiJDBhMTWRvb4+GDx+O1qxcgrxPH0RP7l9B78IDUEpsCKLiniNB3HP0MeoRCg28ji6fP47+W7cSjRo1CrVq1ernnYpSFf87EY0bNw6hfCGPpGii38zt5op0JVctXyyF+S8ep9iXASg0Lt4LE4AKtN4zN5uQFE306e2sBAIQC8Tj+5cRX0CdkjkBAKA6deshVJjFC4ktXeCWHrrpRFI0kS2MuzV96iTEYDLLTow/KW55GkPqd9nWqYv8bvggkqIJbsBLD0XKz/QdPh0QKuZZ1rCSyvyvWcsGIZTPm6Am5/8rPAEghCCGn7TvXVSIcrYEAZDrkCH/YhL+nQAAkKGRCfosiL9U1mf7BEdOJima+PwpCs2cNhnp6en/rJz/EOuQicL/QjBGJiZo44a1CKFMHknRhNuyo/UVLTvv+MkHQnjSXP4Rj8P0aVPV0vyv0ATQb852c5Kiid5KsQIAMTW1UEGm4H4Z99f/QACa37f7Qh//s7D1cF/NuvosahpJ0YQoM5G3e6sXatyk6f8rroLG6MdW28YW7djihVChgEdSNLH6mHLuLDhOXqdHUjThMthF6uBk1DM/FM1P2o0JQMVaVAJ/58e3YUqIBYhXhqP7t5dVWXnDhw7+44rq6+ONSIomHD3W6ZV3bHb6PBpeEqCLfOaPVi6dj2xs6/z+3TLaHfm1GRoaoZHDXdGDWxcQQkU8kqKJjWcfDFKmzPg8ipycncb/ruClEECNmtYIoQKex0b5HUjCBFDOWMCQIS5KsQLq1GuASIomxq491Uz6Y6dTkLGxCTIxrSpuJqbIxMQE7dyxFZEUTYxaebyRLMdo1MrjjULi4r1KyOBTzBN0aM8WNHL4EFTdsibS0GTJLEago6OHGjZsiBbNn4Fu+Z5BCNGoZKdgyibvdqpzjmSZFME/MaktXbxQbc3/Ck8ACCEIi03YlCb4cFnh5wIkwcAXj+9KHQy8H/p2PkK5PIQy0PeWjhDKRCRFE3N2XJbr/veIZUfqnwsUH8slKZooLCxECxYu/rYL8KdvrWJojExMzJCJaVVUo6YVatSoEerSqSMaPswFLVs0Bx3dvx2FPryGUO4nVLKNSFI0MX/ftW493D1ZqiIr68/eH4RQAc/420lSzVJJj0qIRPci3s5XVwJgIFTxLzcKaCGxfdN6zrade0pN6CDbm1TF0NOpF5wlCK77+tNzbu9Z+Lm0Pxmz5lQTHR1tXZFIJPrxpmFKUlL8nf1L0hSZkOPcxpknL18gODNmz//9uCEAABHcuRsAPbu0A00dAHE9WRYAQJBk7PkAALFp6dE3A2JC4hOSP/psll26blnLyb2blzhjJ06XJCBh/nVu7ezbwJ07t7hTNp9ffG17xc8AXKFvA/6tnbgTOg7lp/P0DAxLZ3Y5BLqohNeIF/l+eUU8Vr176/rfWk4MpuY3Mzg2OgIhhHjj1p2xG7nyeKPBC/dZO0/baFiRvnXlsTvOJEUTljVqSX2r0vfcMbU2/9XCBfhRmLlnjin+jgAAGs0ZWSEFhaRoYueW9X/dlgQAlPzuMTr3SLF79fL41kve0twkFe/IGJuYIYRyeSuP/3wKU90aU10smW0Xnx7r4TyQa9eylcIThhDc86DLyDR48FI9K/gWFQOwmBoVVla8ztzvD4Bg9kJPSQKVv32KWHameowHAZ3J93Lv7Q9qDPUhgJkDA/NEolwf7pGfMsooKhvPnAWeg5rUNLV39FBS+TAFZUWqiJjUu4Xb7SsXOClJiaV/CBIBMJiwfMnMm08/CB6DmoOpTh8zee2xeQZmVtxFCxf8GMVSCE6fJUCjII2zbv7YJYChMjh48ymHXdXAav7SNVKs/mJ5GT1qJGQX66e7dGh2EBNABcLdgyuyLj95f3PR0kUXa9ayUZwrILECJk5bAHWqGjZ0XXLAGque8tFz8lptl7Z1+yxatNwh/euX0sVdIi9bNi6DD18y3laGMWKq2wdNH9zRu7iYWejrfUKxrgAw4MbNm0B9es/Zv2DYBqx+yse+1R7bi7JSOdt27JJMEaPU1b9//wHA0Lbgeu29tB8TQAWFx4az82rVacKdN2/uT8wuX/0XD+UY92kAALD8yC0nrILKw4ztlzoYa2kZu42bIoXp/11Gdm5fB5n5hRl+CjyTgQlAxri5e77w8pP3N5csX+bdsGEjBcYCGBAV9QruXL/EmT247TishsrDqjFdZ9y+donzOPgRiAN/pa/+w1yHgIFxDe7sLcSKyjJOTHX9sOmDO3ojEaP4so+3ePIV4QpIVpnpcxaDiS5YXA6OmoZVUfF4/j7BS0uUpzN11sIyrf77dm31fiv4GnVn7+I0TABqAM7y/RNMLKpzD+zbpVBXIC8nCzjjpzp1rM/uxFl9ohFWScXhvzMPBlkZ6dsMHDbKtTA/p/Sj4ZKj8PPnzgKRVpXibs3rba5M46XWBPDg2JrCTd7BR1yGjeS6DHGF7xfX5OsGADDA9/JleP74IWf7zAErsFoqBgPn7bZ079182NFD+zmPg4OlFG8RGBgaw/Zt64Luv+IHVLYxY6r7B+6a7RIUFJMcePjI/ot169ZTaEBwxGgPMGAVG31IERzG6il/HFk2asvb6CjOas+1knmQ4tAPABzZuw0Enwv5o3van8AEoIYY3tXuWHExs/DurcvAYGoqLB6Qm5MJg4Zy+utrauivOubnjFVUfkgQUEc1i3NZAwe5Ssa/tFuhYmuwXfv20L33QO6a0wF7K+O4MSvLh3KW75+ga1yNe/nSRcn8y5sExK5AQEAAHNy/jzNjYKsxw5YessGqKns8fPV+ka4mGDj2GTQ8M+OrdFfCJav/Je5JQABwaNGIEEwAah4PmL714or2nTpzt2zeqBgSkLgC69atg1dhzzh757t6YXWVLS49ejW5Edu4xcTxHm6vIiMAQHrl375lI2gamHE5y/aMrazjx6xMH3t564zEo36R3mPGT+ROnTrlJ2GQHwmIBbLfoGGQlZaaLaCFBFZb2eCk3/NxnRtUd1i8aBHn1q2bYqtLqktLCNq1bQejxk3kHr/7yifguJcIE0AlwaqxPW/eCUu457nWiztg4ECxLyjvrEgMDSgqzIfOXR0n67NERpgEyo/Td8Pc+9jXdlrj6ck5e+b0TxbX33W/GFhaOnDvzqWb+SJR/orRjtcq8zgyK+NHT+jT5nRoHPX4yNFj3E6dOkPJHXB5kwBFkdC2k2N/trG2VRJFn1KFscjLy/3uDv3aJBAVF4EWi6mhKvN37enrac52tXqsWb2ac/jQwZ8srdKUHwDA5/xZyC7STrdmV5tY2YmUWVk/fGDHpgc/fM54e/X6pYv29q0UtjPwNuYN2Hfo4VCzqp6NKlgCpiamYGpqCqZm5v/fTMX/n66uDuhps3RVYd6CouOWt6tTrdP8efM4hw8fKoPyi0l+4fx50K5zV+7c3VfXYTsKANQ53ZE0LSI+ccuXtJTLzZs3V0w6MUmevRZ29qgoJ+2hMlOJ7fJ+NFwgFJxHKBf9rZEURQxferiusueKL6BOfU4jLzn1cv6n8meOjo6IpGhi31X1KvFd6bMClxcxScm7G9UwtGvdprtDWFiY2DBiMOTJugAggoYNG8Hjh3d8C5h6eZxl+yY8OL62UNHfPnTJQRsDAwOjv/2GTObH+R9anqU0a23ubssjy0dtYeanafTsN9QtKioKSs3q+4vpX6uWNSR+fB30MIq82d2u3la89GML4GdLICFxi/AzeaFjx04KqjQktgTY7OooKjwUkRRNuHsR9ngufm5bzwW6khRNPLh7GxkaGpVeefg3K7+BgSFK4ccT6p7ht1JnBZZFe/ru41qSoomBgwYrrtyY5D3niNOIpGhiz+VgbJ6WlIGPT9hAUjSxZvWqfyxyCoipwUIRL0MRVn5MAFI1vxcxs0mKJiZO9FAQCXwvDDpzxgwkEFLnSYomuk9YyaysczBt84V2JEUT9KfoCz2dnH6YB80yE2vQw3uIpGjCafJ6AyzfmACkaqfvvnAnKZrw8lqncBJo1boN+hD9ApEUTaw+qpwKukqr9ThNXOuRpGji0IE94rqF/7jyAwC653cTkRRN9J25zRzLNSaAMjXPY359SYomfC6cR1ra2mX3PctRbxAA0FrPFQihAh5J0cTgefus1Z5074lJ992rZ6h7D8d/J14AxGRqoHt37yCSookBc3ZZYnnGBPBPzXXRARuSook3kc9RvXr1pagqI9u4QNNmzdHDe+JVLIaftK/vDPVbyQ7ffDaGpGgiJ/W938zpU8pXthwA6ekboEe8AERSNNF/9g42lmNMAOVqPSZ6ssQBpGze0GHDFBgcZH57l8uQISju9VNEUjTxLin5wMA5uyv0qtZzkpeeT3DkZJKiiYKv8fdXLluEdHR1y6H44rGqVo2NosKfI5Kiid7TNplg+cUEILN29UnUNJKiiX17diIWS0sxLsEP1gAAoBEjhqN3EY9QiZ+8aO91x4o0hh4bzrVOkfQ9NTESLZg3GxlUMSwfqUrcphYtWiJhSvwFkqKJHhNVpyQ5JgB1ik5vEUenX4eHoBYt7BRnDfxCBN17OKIbl04jhNJ5JEUTT99/XDt69ckmqjhmI1ccbxT8Lm6l2IrK4QX6+aLBLoMRg6lR/vH7ZiG5IoRyeXirDxOA3JvjxDXaYkEr4K1YsVyxJPALEVhb10bzZs9AMWEPEUJ5PJKiiYiExC1bvQNdnacrxwR2nrbRcPP5hy4RCYlbxOOUz3sXzkPz585Gdb/FUWQwZpJnrF61GpEUTVwOfjUNyyc+CqwwbDkf6DLWsYkrlRjDcZ+6AF6+fCH9xRSZHOEEAPh+galBw0bQsX1rGDdiALSybw4GFg2CBLSQn11UnP06KTUi9BX/49vY+Le+W6YnyqoLw5YesmlYr3b9Fo0srVvbVmujw2Tqsi3MrTIEMQ6voqLhlPdNePI0FGJion+8ESX9Ed6/3OgzMTGFs6eOQqv2XbhHbkV4r57gdBNL5T/cT8ME8O/oO2Ob2QnPcbsZTKRx6sght7XrN0Nubo5iieAHpSiBlpYO2NvbQbOmjcC5Wzto2bwR1KhZE7RNagUBaAIAgIAW8gEAUvPyhalZuYKsnMKsgqJiUWFhcWExQsAAAJamBlOLxdQwNtAxMdXXMTfT0TZnAADbwtxK/KYCyE9LchCkkPAsLBLu855D9Nv3EBL6HIqLCv7vOrSsvrN3n77gyz10O6NQJ23aRu9lV3bO4mNpxASgNCzed8Nx/vD2E/RQusHsxV6DTp85I1vB/4eLRr9CT98AbG1twbI6G9jVzKGebS2oXs0cqpoZg7mZCRhVMQAtLU3Q1tYCJoMJIiSCgoJCKCgohC9fM+BzWjp8/pIOn5JIiP+UDBSdCvykJEhISISc7Kzf3zSX1YUqieKzWFqwZdN6cBs9npuclZPYytYap1zHl4FUpwXHiINd4SEByKFrN9n5u+XaSmT83A+5NYZcYx59+/VHQn70BZKiibk7rzhgecMxAJXEgNk72UdXjt4GAPDicQBn5drNEBkZrjyL4K+WQlkLpUhq7MnzqvQvq351yxqwa+t6cOjZj0vl5qa0sK61GEsZtgBUvo3zPGMn2ZbiXb14Btm1tFe+RVARmmR8tLS10erlixBCX3gkRRNjV59qhuUKbwNWuDb5v/OtSw7uPLjji3r06P6L6czESv/DqUcNDU00Z+ZUlPs5zo+kaGLj2QeDsBxhF6DCY+J6rv2Gyb3mAwB84b/mbN93As55+35PyqlK7oESdi909fRg5hR3WL105s0sME2/G/EpYGyvView5OBdALXCoPl7LNfNGTy3mq6uJdsg12r/kfMOx894Q3h4hOy3zVRc6QEAmjRpClPcOTBrxpggQboW//4rfkBlrNGHCaASYot3oMvYHk1cAQAyyBjOKe5lOOdzDRITEuS3paYCSq+rqwfDXAfCVPeR0KH7wCABLeQTAdFXFrp19cVSgQmg0mHokoM2Cyf2Hl/b2KAO28LUKio0wMHnqj/4XrsN0dExv4/GM5gVRuEBALR1dKGvc08YObQ/DBs9KEhAM/l5IlHuygO3dxHrJrzBUoAJAAMAxnudtZs+qotrrSr6NmwLc6tMMsqB8LkDT0Negt/9hyCk6b/MpoZKKHsJrK1rwcB+zuDs2Bn6DekNAprBBQDYe+3F2Q2T+vjj2cYEgPEXDF92pG73Ts3aubSt2wcAgG2hZ0XFvXG4cfcRhL+KgWehYfAmJhby83LKOu3wx/38b/JQtjMCWtq60KRRfejQrjW0a90chg7oAXrV6gUJ6Aw+AMDOyyEnw8LCn94/uioHzywmAIx/wORN3q1b29k0Gmhv6ywmBHMrAKEDPyYWnryIgui38fAx4RN8jE+E5JQUSCEpKCzIk6G0aICZmQlY1awB9erYQu3ataBhXWvo0s4O6rVsAgAWQSV3DM4/irkSFvnhLTbvMQFgyAmD5u+xrGNbq65dY6u6vZrW6lHy72JiyHGA4gzIFNCQLEgFkkoFSvgF0jOzID0jC7KycyE/vwAKC4u+rfiaLBZosVigrc0Cwyr6UNXECEyMDaGqqTFYW1WDajXYADqGAGAcBPD9QlHwezLoWWRC7PsPCbHXts9OwTODCQBDieg7a5uZWdWqbEt2VXZNtol5dfMqhjWrValR00DfWpPB0Pzxt99v9n1X6B+RmpcvFKRn8xNS0oV8Mu0zJfz6WUDRKVe34Rt4mAAwMDAqNJh4CDAwMAFgYGBgAsDAwMAEgIGBgQkAAwMDEwAGBgYmAAwMDEwAGBgYmAAwMDAwAWBgYGACwMDAwASAgYGBCQADAwMTAAYGBiYADAwMVcX/BgBuXfH22VFPbwAAAABJRU5ErkJggg=="

/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = require("electron-devtools-installer");

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var host = exports.host = function host(path) {
  return 'http://46.101.209.10:3005' + path;
};

global.host = host; // Localhost path
global.getToken = function () {
  return localStorage.getItem('token');
}; // Get localStorage token

/***/ })
/******/ ]);